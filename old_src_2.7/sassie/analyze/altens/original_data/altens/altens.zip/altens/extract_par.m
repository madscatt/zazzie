function [A,B,C,D,E]=extract_par(mat)

A=mat(2,2);
B=mat(3,3);
C=mat(1,2);
D=mat(1,3);
E=mat(2,3);

return