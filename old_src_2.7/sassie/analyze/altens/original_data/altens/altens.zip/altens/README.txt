The main program is 

altens.m

Its header describes how it is called, what it outputs and various options.

Some of the scripts in this folder are not used at all -- these are remnants 
of the 14 years of use and modifications of this package. 