function aniso=calc_ani(S)


aniso=(S(1)-S(2))/S(3);
return