function [r1,r2,r3]=rap(a,b,c)
r1=a/a;
r2=b/a;
r3=c/a;
return