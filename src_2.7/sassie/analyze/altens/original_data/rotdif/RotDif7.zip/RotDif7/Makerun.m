%script to execute different demo files


cd ../Dynamics_ani
load vNH.mat
Makedemo8
save 1.mat
clear



cd ../Dynamics_ani
load vNH.mat
Makedemo9
save 2.mat
clear

cd ../Dynamics_ani
load vNH.mat
Makedemo10
save 3.mat
clear







