function f=calcDx(Tx)
f=(1/(6*Tx))*1e2;
return