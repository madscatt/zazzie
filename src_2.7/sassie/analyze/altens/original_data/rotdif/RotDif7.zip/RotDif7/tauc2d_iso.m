function z=tauc2d_iso(pariso);

z=(1/(6*pariso))*1e2;
return