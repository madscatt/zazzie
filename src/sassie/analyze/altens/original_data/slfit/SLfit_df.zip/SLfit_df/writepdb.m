function fid=writepdb(coor,at_res,atnam,option,filnam,report,chainID,kheader,model)
%-------------------------------------------------------------
%   df-aug-13 fixed a bug in identifying a single-letter atom name 
%   df-dec-07 add MODEL option
%   df-nov-07 control writing our header
%   df-jul-06 fixed the number of spaces, added the option of 
%             inserting/modifying chain ID (character, e.g. 'A')
%   df-sep-04 added atom names at end of line, MATLAB-header,
%   removed 'MATLAB' at end of line
%   df-may-03 (added filenam as input param) df-sep-01
%	given protein coordinates, atom names etc,
%	write out a pdb file
%	option = 'w' to write (rewrite)
%				'a' to append
%   input chainID if you want to modify chainID
%   kheader = 1 to write out the Matlab header (default)
%             0 to supress writing the header
%   model = model number; will write MODEL and ENDMODEL 
%		if empty, no MODEL/ENDMODEL message is written
%-------------------------------------------------------------
if nargin < 9, model = []; end      %default: no model message
if nargin < 8, kheader = 1; end     %default: write header
if nargin < 7, chainID = []; end    %default: no chain ID
if nargin < 6, report =1; end       %default: report = on 
if nargin < 5, filnam=[]; end       %default: manual input
if isempty(filnam)
    filnam=input('output pdb-file full name (str) ==> ','s');
    filnam=deblank(filnam);
    if isempty(findstr(filnam,'.')),filnam=[filnam,'.pdb'];end
elseif ~ischar(filnam), 
    disp('filename must be a string!')
    return
end
if nargin < 4, option='w'; end	%default: rewrite
if ~isempty(chainID),
   if length(chainID) > 1, error('wrong chainID: length must =1'); end
   if ~ischar(chainID), error('wrong chainID: must be a character'); end
end
nat=size(coor,1);
if ~isempty(filnam), 
  fid=fopen(filnam,option);
  if fid==-1, error(['cant open file ',filnam]); end
  printheader = ['HEADER    MATLAB-GENERATED ATOM COORDINATES  ',upper(date),'\r\n'];
  %fprintf(fid,'HEADER    MATLAB-GENERATED ATOM COORDINATES\r\n');
  if kheader == 1, fprintf(fid,printheader); end
  if ~isempty(model), 
       strmodel = num2str(model); 
       printmodel = ['MODEL',blanks(9-length(strmodel)),strmodel,'\r\n'];
       fprintf(fid,printmodel); 
  end
  %printline='ATOM   %s     %8.3f%8.3f%8.3f  1.00 00.00           %s  \r\n';
   printline='ATOM   %s    %8.3f%8.3f%8.3f  1.00 00.00           %s  \r\n';
  for ii=1:nat,
     %what if a coor is longer than the allowed space? need to prevent shifts in the formatted input
     %the next lines are just a patch, assuming that only 1 out of the 3 coordinates can
     %get out of allocated formatted space
%     if coor(ii,1)-rem(coor(ii,1),1)>=1000 | coor(ii,1)-rem(coor(ii,1),1)<= -100,
%         printline='ATOM   %s    %8.3f%8.3f%8.3f  1.00 00.00           %s  \r\n';
%     elseif coor(ii,2)-rem(coor(ii,1),2)>=1000 | coor(ii,2)-rem(coor(ii,2),1)<= -100,
%         printline='ATOM   %s     %7.3f%7.3f %7.3f  1.00 00.00           %s  \r\n';
%     elseif coor(ii,3)-rem(coor(ii,1),3)>=1000 | coor(ii,3)-rem(coor(ii,3),1)<= -100,
%         printline='ATOM   %s     %7.3f %7.3f%7.3f  1.00 00.00           %s  \r\n';
%     else
%         printline='ATOM   %s     %7.3f %7.3f %7.3f  1.00 00.00           %s  \r\n';
%     end


%    find the proper character for atom name
     if isspace(atnam(ii,6)), 
         atom = atnam(ii,7); 
     else
        if isempty(findstr(atnam(ii,6),'1234567890')),
           atom = atnam(ii,6);
        else 
           atom = atnam(ii,7); 
        end
            %strcmp(atnam(ii,6),'1')|strcmp(atnam(ii,6),'1')|strcmp(atnam(ii,6),'1') 
     end
     if ~isempty(chainID),  %add/modify chain identifier
        fprintf(fid,printline,[atnam(ii,1:14),chainID,atnam(ii,16:end)],coor(ii,1),coor(ii,2),coor(ii,3),atom);  
     else           %no chainID addition or modification
        fprintf(fid,printline,atnam(ii,:),coor(ii,1),coor(ii,2),coor(ii,3),atom); 
     end
     %store a letter at the end
     % fprintf(fid,printline,atnam(ii,:),coor(ii,1),coor(ii,2),coor(ii,3),atnam(ii,15));
  end
  fprintf(fid,'TER\r\n'); 
  if ~isempty(model), fprintf(fid,'ENDMDL\r\n'); end
  fclose(fid);
  if report==1, %print report on screen
    if strcmp(option,'w'),
      disp(['data written to file ',filnam])
    elseif strcmp(option,'a'),
      disp(['data appended to file ',filnam])
    end
  end
end
return
%============================================================   

%sel=select_at(atnam,at_res,[],'N C O CA',2);
%  printline='ATOM   %s     %7.3f %7.3f %7.3f   1.00 00.00       MATLAB\r\n';
% fprintf(fid,printline,atnam(ii,:),coor(ii,1),coor(ii,2),coor(ii,3));