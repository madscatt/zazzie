%script to generate PRE data for an ensemble of structures (EROS)
load ind_eros
res(:)=res;
z=[res,NaN*ones(length(res),116)];
T2dia=50e-3;
Htime=0.005;
freq=600.13;
TAUc=4.5;

for ii=1:116,
    [coor,atnam,at_res]=readpdb('c:/pdb/2k39_EROS.pdb',[],[],ii);
    SLcoord=coor(indC,:);
    Hcoord=coor(indH,:);
    ratio_sim=Sim_SLdataCoor(res,T2dia,Htime,freq,TAUc,Hcoord,SLcoord);
    z(:,ii+1)=ratio_sim(:,2);
    ii
end
