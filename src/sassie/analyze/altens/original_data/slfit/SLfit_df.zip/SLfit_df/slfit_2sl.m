function [position,ratio_dist,Chi2]=SLfit_2sl(ratio,T2dia,Htime,freq,TAUc,pdb_filename,out_filename,guess,reslist,scaling,model,nweights)
%-----------------------------------------------------------------------------
%   df-jul-14   an attempt to fit to two SLs
% df-oct-09  %df-Aug-09    (based on earlier program SL_fit by YR, YaR-jan-2006)
%   Given protein coordinates and signal attenuations due to PRE effect, determine 
%   the position of the unpaired electron of the spin label 
%   The program outputs a PDB file containing the input protein coordinates and
%   appended to them coordinates of a fake atom representing the SL. (Make sure you have 
%   the proper write permissions!)
%
% INPUT:
%   ratio - a [Nres x 2] matrix, with the first column containing residue numbers and 
%           the second containing the ratio of signal intensities (Iox/Ired) recorded
%           with the SL in the oxidized (Iox, PRE) and reduced (Ired, no attenuation) forms  
%   T2dia - (scalar) amide proton T2 in diamagnetic state, [in seconds]
%   Htime - (scalar) time during the pulse sequence (excluding acquisition time) when the 
%           magnetization is in 1H, [in seconds]
%   freq -  (scalar) 1H frequency [in MHz] (e.g. 600.13)
%   TAUc -  (scalar) overall correlation time of the protein [in nanoseconds]
%   pdb_filename - (string) filename of the atom coordinates of the protein (PDB structure)
%   out_filename - (string) name of the output PDB file containing an additional atom, S, 
%           representing the unpaired electron of the SL as a fake CYS residue appended at the 
%           end of the file as 9999  S   CYS   999. Make sure you have the "write" permission.
%           Input empty filename ([]) to suppress pdb output
%   guess  -  ([1x6] vector) is the initial guess for spin labels coordinates in the PDB 
%           file coordinate frame, in the format [X1 Y1 Z1 X2 Y2 Z2], in Angstroms. (default: []).
%		Entering the empty vector (default) will generate from atom coordinates a cube of guesses 
%   reslist -- list of residues to analyze. Default ([]): all residues in the ratio set 
%   scaling - (scalar) an adjustable scaling factor which adjusts the Iox/Ired ratio in order 
%           to have the maximal value less than or equal to 1, (default: 1)
%   model - model number from PDB file to be used
%   nweights - number of weight points (from 0 to 1) to be screened (default: 10)
%
% OUTPUT
%   position = [X1 Y1 Z1 X2 Y2 Z2 weight1] is the vector of fitted spin labels postions in the PDB frame (in Angstroms)
%			and the weight of the first SL 
%   ratio_dist = [Nres x 5] matrix containing back-calculated intensity ratios and distances
%                from SLs for all amide Hs in the protein, and the experimental ratios (scaled!)
%   Chi2 =    value of the target function at the minimum
%--------------------------------------------------------------------------------

%tic
% check input, set defaults
if nargin < 12, nweights = 10; end              %default nweights = 10
if nargin < 11, model = 1; end                  %default model = 1
if nargin < 10, scaling = 1; end                %default scaling = 1
if nargin < 9, reslist = []; end                %default: all residues from the ratio list
if nargin < 8, guess = []; end                  %default guess = automatic
if nargin < 7, out_filename=[]; end             %default: write to the same file
if nargin < 9, scaling = 1; end                 %default scaling = 1

%set/convert params
omega = freq*2*pi*1e6;                          %convert frequency to rad/sec    
d2 = 1.23e-44;                                  % 1/15*S(S+1)*gammaH^2*g^2*beta^2 (m^6 s^-2)
d2 = d2*(1e10^6);                               %convert d2 to A^6 s^-2
tauC = TAUc*1e-9;                               %convert to seconds    
R2dia = 1/T2dia;                                %convert T2 into R2 
factor = d2*(4*tauC+3*tauC/(1+(omega*tauC)^2)); %factor in the Eq for SL

% initialize output params
position =[];
ratio_dist=[];
Chi2 = inf;

% scale intensity ratio 
ratio(:,2)=ratio(:,2)*scaling;
rlist_ratio=ratio(:,1);
nres_ratio=length(rlist_ratio);

%get coordinates for ALL N and H atoms
%model=1;                                        %take the first model from the input PDB file
NHcoord=pdb2nhcoor(pdb_filename,[],model,0);

nNH = size(NHcoord(:,1),1);

%select for analysis only those NH groups that have PRE data
%get the indices
ind_ratio=NaN*ones(nres_ratio,1);
ind_NH=NaN*ones(nNH,1);
for ii=1:nres_ratio,
  if ~isempty(reslist), 
      indB=find(reslist(:) == rlist_ratio(ii));
  else 
      indB=1;
  end
  if ~isnan(ratio(ii,2)) & ~isempty(indB),       %check if RPE data are not NaN
    indA=find(NHcoord(:,1)==rlist_ratio(ii));
    if ~isempty(indA), 
	if ~isnan(NHcoord(indA,2:end)), %check for NaNs
        ind_NH(indA)=indA;
        ind_ratio(ii)=ii;
	end
    end
  end
end

%automatic guess: create a cube
if isempty(guess), 
  max_corner=max(NHcoord(~isnan(NHcoord(:,2)),2:4));
  min_corner=min(NHcoord(~isnan(NHcoord(:,2)),2:4));
  center=mean(NHcoord(~isnan(NHcoord(:,2)),2:4));
  cube=[min_corner;...
    [min_corner(1),min_corner(2),max_corner(3)];...
    [min_corner(1),max_corner(2),min_corner(3)];...
    [max_corner(1),min_corner(2),min_corner(3)];...
    [min_corner(1),max_corner(2),max_corner(3)];...
    [max_corner(1),min_corner(2),max_corner(3)];...
    [max_corner(1),max_corner(2),min_corner(3)];...
    max_corner];
    %extended cube: center and faces:
  cube_faces=[center;...
    [min_corner(1),center(2),center(3)];...
    [center(1),min_corner(2),center(3)];...
    [center(1),center(2),min_corner(3)];...
    [max_corner(1),center(2),center(3)];...
    [center(1),max_corner(2),center(3)];...
    [center(1),center(2),max_corner(3)]];
  cube=[cube;cube_faces];
  disp('cube of automatic guesses generated')
  cube_points=size(cube,1);
end    


%de-NaN the indices
ind_ratio = ind_ratio(~isnan(ind_ratio));
ind_NH = ind_NH(~isnan(ind_NH));

%prepare data sets for fit 
fit_coord = NHcoord(ind_NH,[1,5:7]);                %take protons only, for now
fit_ratio = ratio(ind_ratio,:);
%nres_ratio = length(ind_ratio);

%fitting of paramagnetic ion position

options = optimset('TolFun',1e-9,'TolX',1e-9,'MaxFunEvals',1000000,'MaxIter',100000); %options for minimization (could be different for Matlab 7!)
weight1=linspace(0,1,nweights)';
%res=NaN*ones(length(weight1),8);
%res(:,1)=weight1;
%for ii=1:length(weight1),
%   [position, Chi2]=fminsearch('SLfit_2sl_ss',guess,options,fit_ratio,fit_coord,factor,R2dia,Htime,weight1(ii)); %simplex minimization
%   res(ii,2)=Chi2;
%   res(ii,3:8)=position;
%end
%position=res;

%Chi2=inf;
if isempty(guess),                      %automatic guess: on a cube
  for jj=1:cube_points-1,
   for kk=jj+1:cube_points,
    guess=[cube(jj,:),cube(kk,:)];           %initial guesses
    for ii=1:length(weight1),                      %weight1 on a grid, to assure 0 <= weight1 <= 1 
      [pos_tmp, Chi2_tmp]=fminsearch('SLfit_2sl_ss',guess,options,fit_ratio,fit_coord,factor,R2dia,Htime,weight1(ii)); %simplex minimization
      if Chi2 > Chi2_tmp,
         Chi2=Chi2_tmp;
         position=pos_tmp;
         weight_ind=ii;
      end
    end
    disp([jj,kk])
   end
  end
else                                    %take input value for the guess
    for ii=1:length(weight1),                      %weight1 on a grid, to assure 0 <= weight1 <= 1 
      [pos_tmp, Chi2_tmp]=fminsearch('SLfit_2sl_ss',guess,options,fit_ratio,fit_coord,factor,R2dia,Htime,weight1(ii)); %simplex minimization
      if Chi2 > Chi2_tmp,
         Chi2=Chi2_tmp;
         position=pos_tmp;
         weight_ind=ii;
      end
    end
end
position=[position, weight1(weight_ind)];
[position(1:6),Chi2,position(7)]

disp(' ');
disp('Position of the Spin Label in the PDB coordinate frame: ');
disp([' X1 = ',num2str(position(1)),' A']);
disp([' Y1 = ',num2str(position(2)),' A']);
disp([' Z1 = ',num2str(position(3)),' A']);
disp([' Weight_1 = ',num2str(position(7))]);
disp([' X2 = ',num2str(position(4)),' A']);
disp([' Y2 = ',num2str(position(5)),' A']);
disp([' Z2 = ',num2str(position(6)),' A']);
disp([' Weight_2 = ',num2str(1-position(7))]);
disp(' ');
disp(['Chi^2 = ',num2str(Chi2)]);
disp(' ');

%write resulting file
if ~isempty(out_filename),
    [s,w]=SL_add2pdb(pdb_filename,out_filename,[position(1:3);position(4:6)],[[9998 998];[9999 999]]);
end

%back-calculate and report intensities and distances (from SL) for ALL H atoms
nres = size(NHcoord,1);
ratio_dist = NaN*ones(nres,5);
fit_ind = [];
weight1 = position(7);           
for ii=1:nres,
    Hvect1 = NHcoord(ii,5:7)-position(1:3);
    Hvect2 = NHcoord(ii,5:7)-position(4:6);
    dist1 = sqrt(Hvect1*Hvect1');
    dist2 = sqrt(Hvect2*Hvect2');
    R2para1 = factor/(dist1^6); %evaluate Rpara
    R2para2 = factor/(dist2^6); %evaluate Rpara
    ratio_sim = weight1*R2dia*exp(-R2para1*Htime)./(R2para1+R2dia)+...
        (1-weight1)*R2dia*exp(-R2para2*Htime)./(R2para2+R2dia);
    ratio_dist(ii,1:4) = [NHcoord(ii,1),ratio_sim,dist1,dist2];
    indnn = find(fit_ratio(:,1) == ratio_dist(ii,1));        %insert PRE data (scaled)
    if ~isempty(indnn),
        ratio_dist(ii,5) = fit_ratio(indnn,2);              %record input data that were fit
        fit_ind=[fit_ind;ii];                               %index of which are fitted data
    end
end
figure(2)
hold off
bar(ratio(:,1),ratio(:,2)); hold on
h=plot(ratio_dist(:,1),ratio_dist(:,2),'ro-',ratio_dist(fit_ind,1),ratio_dist(fit_ind,2),'o');
%plot(ratio_dist(:,1),ratio_dist(:,2),'ro-',ratio_dist(fit_ind,1),ratio_dis
%t(fit_ind,2),'r*',ratio_dist(:,1),ratio_dist(:,5),'g*')
%set(h(1),'MarkerEdgeColor','r','MarkerFaceColor','none');
set(h(2),'MarkerEdgeColor','none','MarkerFaceColor','r');
xlabel('residue')
ylabel('ratio')
title('bars=experiment, o=prediction, *=actual fit')

return

%=======================================================

%Example: [position,ratio_dist,Chi2]=SLfit(ratio_sim,50e-3,5e-3,600.13,4.5,'1D3Z.pdb','test_df3.pdb',[0 0 0 100 100 100],[2:70]);
%Example: [position,ratio_dist,Chi2]=SLfit(ratio_sim,50e-3,5e-3,600.13,4.5,'1D3Z.pdb','test_df3.pdb',[],[]);
