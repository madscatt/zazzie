%this is a script to run Karina's MTSL data against the EROR ensemble
res=NaN*ones(116,4);
for ii=1:116,
[position,ratio_dist,Chi2]=SLfit(ratio,42e-3,5e-3,800,4.5,'D:\Programs\PDB\2k39_EROS.pdb',[],[],[2:51,53:76],1.15,ii);
res(ii,:)=[position, Chi2];
end
res_76wo52new=res;

return
[coor,atnam,at_res]=readpdb('D:\Programs\PDB\2k39_EROS.pdb',[],[],100);