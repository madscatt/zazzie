function z=PRE2dist(ratio,T2dia,Htime,freq,TAUc)
%-----------------------------------------------
%   df-oct-14
%   convert PREs to distances
%-----------------------------------------------

%set/convert params
omega = freq*2*pi*1e6;                          %convert frequency to rad/sec    
d2 = 1.23e-44;                                  % 1/15*S(S+1)*gammaH^2*g^2*beta^2 (m^6 s^-2)
d2 = d2*(1e10^6);                               %convert d2 to A^6 s^-2
tauC = TAUc*1e-9;                               %convert to seconds    
R2dia = 1/T2dia;                                %convert T2 into R2 
factor = d2*(4*tauC+3*tauC/(1+(omega*tauC)^2)); %factor in the Eq for SL

nres=size(ratio,1);
z=NaN*ones(nres,3);
z(:,1)=ratio(:,1);
for ii=1:nres,
    if ~isnan(ratio(ii,2)),
      if ratio(ii,2)==0, ratio(ii,2)=0.00000001; end  
      if ratio(ii,2)>1, ratio(ii,2)=0.99999999; end
      X0=R2dia*(1-ratio(ii,2))/(ratio(ii,2)+Htime*R2dia);
      X = fzero(@(x) ratio(ii,2)*(x+R2dia)-R2dia*exp(-x*Htime),2);
      z(ii,2)=X;
    end
end
z(:,3)=(factor./z(:,2)).^(1/6);


return
R2para = factor./(dist.^6);   %calc R2para

%calculate intensity ratio

ratio_sim=R2dia*exp(-R2para*Htime)./(R2para+R2dia);

