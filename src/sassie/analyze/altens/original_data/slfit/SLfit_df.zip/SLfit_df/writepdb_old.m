function fid=writepdb(coor,at_res,atnam,option,filnam,report)
%-------------------------------------------------------------
%  df-may-03 (added filenam as input param) df-sep-01
%	given protein coordinates, atom names etc,
%	write out a pdb file
%	option = 'w' to write (rewrite)
%				'a' to append
%------------------------------------------------------------- 
if nargin < 6, report =1; end   %default: report = on 
if nargin < 5, filnam=[]; end	%default: manual input
if isempty(filnam)
    filnam=input('output pdb-file full name (str) ==> ','s');
    filnam=deblank(filnam);
    if isempty(findstr(filnam,'.')),filnam=[filnam,'.pdb'];end
elseif ~ischar(filnam), 
    disp('filename must be a string!')
    return
end
if nargin < 4, option='w'; end	%default: rewrite

nat=size(coor,1);
if ~isempty(filnam), 
  fid=fopen(filnam,option);
  if fid==-1, error(['cant open file ',filnam]); end
  printline='ATOM   %s     %7.3f %7.3f %7.3f  1.00 00.00           S  \r\n';
  for ii=1:nat,
     fprintf(fid,printline,atnam(ii,:),coor(ii,1),coor(ii,2),coor(ii,3));
  end
  fprintf(fid,'TER\r\n'); 
  fclose(fid);
  if report==1, %print report on screen
    if strcmp(option,'w'),
      disp(['data written to file ',filnam])
    elseif strcmp(option,'a'),
      disp(['data appended to file ',filnam])
    end
  end
end
return
%============================================================   

%sel=select_at(atnam,at_res,[],'N C O CA',2);
