indD=[];
for ii=1:1230,
if ~isempty(regexp(atnam(ii,:),'HN')), indD=[indD;ii]; end
end


indP=[];
for ii=1:1172,
if ~isempty(regexp(atnam1(ii,:),'HN')), indP=[indP;ii]; end
end