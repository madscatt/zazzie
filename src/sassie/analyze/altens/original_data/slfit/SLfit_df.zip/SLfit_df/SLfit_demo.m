% this is a demo example that generates "experimental" data and then fits them

% generate PRE data for ubiquitin, assuming that the unpaired electron of MTLS 
% is positioned on the C-terminal OXT of GLY75 (uses the first model from PDB entry
% 1D3Z as atom coordinates of ubiquiti)
% in this example, it is assumed that the experimental PRE data are available only 
% for a selected set of residues: 2-18, 34-50, and 60-76. 

% all definitions of the input and output params are in SLfit.m 

%generate experimental data
reslist=[2:18,34:50,60:76];
ratio_sim=Sim_SLdata(reslist,50e-3,5e-3,600.13,4.5,'1D3Z_f.pdb',[44.230 -71.255 -25.266]);
disp('data generated successfully, now fitting them')

%or get the same results by inserting the residue list directly into the command line
%ratio_sim=Sim_SLdata([2:18,34:50,60:76],50e-3,5e-3,600.13,4.5,'1D3Z_f.pdb',[44.230 -71.255 -25.266]);

%in order to generate PRE data for all residues, set reslits=[] or run the previous command as
%ratio_sim=Sim_SLdata([],50e-3,5e-3,600.13,4.5,'1D3Z_f.pdb',[44.230 -71.255 -25.266]);

%add noise to experim data:
noise_std = 0.03;
ratio_sim(:,2)=ratio_sim(:,2).*(1+noise_std*randn(size(ratio_sim,1),1));

%for the data (as initial guess I used [50 50 50])
[position,ratio_dist,Chi2]=SLfit(ratio_sim,50e-3,5e-3,600.13,4.5,'1D3Z_f.pdb','test_SLfit.pdb',[50 50 50]);


% Note: if you want to append consecutive results to the same coordinate file, use the output of the 
% first run (out_filename) as both input (pdb_filename) and output (out_filename) for the next runs.