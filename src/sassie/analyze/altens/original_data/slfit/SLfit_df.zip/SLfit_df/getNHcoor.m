function NHcoor=getNHcoor(coor,atnam,at_res,reslst,offs)
%-------------------------------------------------
%  df-may-03    df-dec-97
%       retrieve the NH coordinates from coor data set
%       in the format: [res#,Nx,Ny,Nz,Hx,Hy,Hz]
%       offs=-1 if amide hydr.=H in the pdb-data set
%       uses: select.m
%-------------------------------------------------
  if nargin<5, offs=0;  end             %default
  %----------select the amide N's-------
  selN=select(atnam,at_res,reslst,'N ',2);
  iN=length(selN);
  %----------select the amide H's-------
  if offs==-1,                          %insight-type naming
    selH=select(atnam,at_res,reslst,' H ',3,-1);
  else
    selH=select(atnam,at_res,reslst,'HN',2,offs);
  end
  iH=length(selH);
  if iH==0, 
     disp(['offs=',num2str(offs),': no amide protons found!']);
     NHcoor=[];
     return   
  end
  disp([num2str(iH),' amide protons found']);
  NHcoor=NaN*ones(iH,7);
  NHcoor(:,1)=at_res(selH,2);
  %-----filter the PROlines out ------
  for ii=1:iH,
    for jj=1:iN,
       if at_res(selN(jj),2)==at_res(selH(ii),2),
          NHcoor(ii,2:4)=coor(selN(jj),:);
          NHcoor(ii,5:7)=coor(selH(ii),:);
          break
       end
    end
  end

return
%=====================================================

