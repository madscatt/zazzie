 function [s,w]=SL_add2pdb(old_file,new_file,SL_coor,SL_at_res)
 %------------------------------------------------
 %  df-jul-14   added choice of at_res numbers
 %  df-oct-09  (backslash conversion)     df-may-03
 %  copy old file to a new file and append a line 
 %  with SL coordinates
 %  atom and residue number can be user defined but
 %  ! atom number not to exceed 9999
 %  ! residue number not to exceed 9999
 %------------------------------------------------

 if nargin < 4, SL_at_res=[9999,999]; end    %default
 [nat,dummy]=size(SL_coor);
 [nat1,dummy1]=size(SL_at_res);
 if nat~=nat1, disp('!!!size mismatch of SL_coor and SL_at_res!!! skipped write to PDB'); return; end
 
 if isunix, 
     old_file = strrep(old_file,'\','/');
     new_file = strrep(new_file,'\','/');
     [s,w]=unix(['cp ',old_file,' ',new_file]);
 else   %dos
     old_file = strrep(old_file,'/','\');
     new_file = strrep(new_file,'/','\');
     [s,w]=dos(['copy ',old_file,' ',new_file]);
 end
 
 if s~=0, disp(w); end
 SL_atnam = [];
 for ii=1:nat,
    atnum=num2str(SL_at_res(ii,1));
    resnum=num2str(SL_at_res(ii,2));
    SL_atnam=[SL_atnam;blanks(4-length(atnum)),atnum,'  S   CYS  ',blanks(4-length(resnum)),resnum];
 end
% SL_atnam='9999  S   CYS   999';
% SL_atnam='9999  S   CYS   999';
% SL_at_res=[9999,999];
 fid=writepdb(SL_coor,SL_at_res,SL_atnam,'a',new_file,0,[],0);
 if s==0 & fid~=-1, disp(['data copied/appended to file ',new_file]); end
 return
 %================================================