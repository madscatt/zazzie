function ratio_sim=Sim_SLdata(reslist,T2dia,Htime,freq,TAUc,pdb_filename,SLcoord,factor);
%-----------------------------------------------------------------
%   df-oct-09    YaR-jan-2006
%   Simulate PRE effect (signal attenuation) given coordinates of protein atoms (PDB file)
%   and coordinates of the spin label 
%   input notations are similar to SLfit.m program
%
%   INPUT:
%   reslist -- (vector) list of residues, input [] means take all residues 
%           with the SL in the oxidized (Iox, PRE) and reduced (Ired, no attenuation) forms  
%   T2dia - (scalar) amide proton T2 in diamagnetic state, [in seconds]
%   Htime - (scalar) time during the experiment when the magnetization is in 1H, [in seconds]
%   freq -  (scalar) 1H frequency [in MHz] (e.g. 600.13)
%   TAUc -  (scalar) overall correlation time of the protein [in nanoseconds]
%   pdb_filename - (string) filename of the atom coordinates of the protein (PDB structure)
%   SLcoord = [X Y Z] is the vector of spin label coordinates in the PDB frame (in Angstroms) 
%   factor - (scalar) is the factor in equation converting the distance from the SL to PRE-caused 
%           signal attenuation: %factor=1/15*S(S+1)*gamma^2*g^2*beta^2 = 1.23e16 (A^6 s^-2) for MTSL  
%
%   OUTPUT
%   ratio_sim = a [Nres x 2] matrix, with the first column containing residue numbers and 
%           the second containing the ratio of signal intensities (Iox/Ired)
%-------------------------------------------------------
if nargin < 8,                                  %default: MTSL
    factor = 1.23e16;                           % 1/15*S(S+1)*gammaH^2*g^2*beta^2 (A^6 s^-2)
end                                             %default: MTSL

%conversions:
omega = freq*2*pi*1e6;                          %convert frequency to rad/sec    
tauC = TAUc*1e-9;                               %convert to seconds    
R2dia = 1/T2dia;                                %convert T2 into R2 
factor = factor*(4*tauC+3*tauC/(1+(omega*tauC)^2)); %factor in the Eq for SL

%read in protein coordinates
model=1; %for the first structure in the input PDB file
NHcoord=pdb2nhcoor(pdb_filename,reslist,model);
at_coord=NHcoord(:,[1,5:7]);

%calculate distances from SL
at_coord(:,2)=at_coord(:,2)-SLcoord(1); %shift of X
at_coord(:,3)=at_coord(:,3)-SLcoord(2); %shift of Y
at_coord(:,4)=at_coord(:,4)-SLcoord(3); %shift of Z

dist=sqrt(at_coord(:,2).^2+at_coord(:,3).^2+at_coord(:,4).^2);

%calcluate R2para and the PRE effect

R2para=factor./((dist).^6); %evaluate Ppara
ratio_sim(:,1)=NHcoord(:,1);
ratio_sim(:,2)=R2dia*exp(-R2para*Htime)./(R2para+R2dia);
%plot the results
figure(1);   %shows simulated attenuation data
hold off;
plot(ratio_sim(:,1),ratio_sim(:,2),'-or')
figure(2); 
hold off;
bar(ratio_sim(:,1),(1-ratio_sim(:,2))*100)

return
%===========================================================