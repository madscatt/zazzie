function [position,ratio_dist,Chi2]=SLfit(ratio,T2dia,Htime,freq,TAUc,pdb_filename,out_filename,guess,scaling,model)
%-----------------------------------------------------------------------------
%   df-jul-14   default guess = geometrical center of coordinates (COM) 
%               enter [] out_filename to suppress pdb output
% df-oct-09  %df-Aug-09    (based on earlier program SL_fit by YR, YaR-jan-2006)
%   Given protein coordinates and signal attenuations due to PRE effect, determine 
%   the position of the unpaired electron of the spin label 
%   The program outputs a PDB file containing the input protein coordinates and
%   appended to them coordinates of a fake atom representing the SL. (Make sure you have 
%   the proper write permissions!)
%
% INPUT:
%   ratio - a [Nres x 2] matrix, with the first column containing residue numbers and 
%           the second containing the ratio of signal intensities (Iox/Ired) recorded
%           with the SL in the oxidized (Iox, PRE) and reduced (Ired, no attenuation) forms  
%   T2dia - (scalar) amide proton T2 in diamagnetic state, [in seconds]
%   Htime - (scalar) time during the pulse sequence (excluding acquisition time) when the 
%           magnetization is in 1H, [in seconds]
%   freq -  (scalar) 1H frequency [in MHz] (e.g. 600.13)
%   TAUc -  (scalar) overall correlation time of the protein [in nanoseconds]
%   pdb_filename - (string) filename of the atom coordinates of the protein (PDB structure)
%   out_filename - (string) name of the output PDB file containing an additional atom, S, 
%           representing the unpaired electron of the SL as a fake CYS residue appended at the 
%           end of the file as 9999  S   CYS   999. If no filename is specified, the output  
%           goes to the input file (make sure you have the "write" permission)
%           enter empty filename ([]) to suppress pdb output
%   guess  -  ([1x3] vector) is the initial guess for spin label's coordinates in the PDB 
%           file coordinate frame, in the format [X Y Z], in Angstroms. (default: COM).
%   scaling - (scalar) an adjustable scaling factor which adjusts the Iox/Ired ratio in order 
%           to have the maximal value less than or equal to 1, (default: 1)
%   model - model number from PDB file to be used
%
% OUTPUT
%   position = [X Y Z] is the vector of fitted spin label postion in the PDB frame (in Angstroms) 
%   ratio_dist = [Nres x 4] matrix containing back-calculated intensity ratios and distances
%                from SL for all amide Hs in the protein, and the experimental ratios (scaled!)
%   Chi2 =    value of the target function at the minimum
%--------------------------------------------------------------------------------

%tic
% check input, set defaults
if nargin < 10, model = 1; end                  %default model = 1
if nargin < 9, scaling = 1; end                 %default scaling = 1
if nargin < 8, guess_COM = 1; else guess_COM = 0; end             %default guess = COM of coordinates
if nargin < 7, out_filename=pdb_filename; end   %default write to the same file
if nargin < 9, scaling = 1; end                 %default scaling = 1

%set/convert params
omega = freq*2*pi*1e6;                          %convert frequency to rad/sec    
d2 = 1.23e-44;                                  % 1/15*S(S+1)*gammaH^2*g^2*beta^2 (m^6 s^-2)
d2 = d2*(1e10^6);                               %convert d2 to A^6 s^-2
tauC = TAUc*1e-9;                               %convert to seconds    
R2dia = 1/T2dia;                                %convert T2 into R2 
factor = d2*(4*tauC+3*tauC/(1+(omega*tauC)^2)); %factor in the Eq for SL

% initialize output params
position =[NaN NaN NaN];
ratio_dist=[];
Chi2 = NaN;

% scale intensity ratio 
ratio(:,2)=ratio(:,2)*scaling;
rlist_ratio=ratio(:,1);
nres_ratio=length(rlist_ratio);

%get coordinates for ALL N and H atoms
%model=1;                                        %take the first model from the input PDB file
NHcoord=pdb2nhcoor(pdb_filename,[],model,0);

nNH = size(NHcoord(:,1),1);
if guess_COM == 1, guess = mean(NHcoord(:,2:4)); disp('guess = COM'); end
    
%select for analysis only those NH groups that have PRE data
%get the indices
ind_ratio=NaN*ones(nres_ratio,1);
ind_NH=NaN*ones(nNH,1);
for ii=1:nres_ratio,
  if ~isnan(ratio(ii,2)),       %check if RPE data are not NaN
    indA=find(NHcoord(:,1)==rlist_ratio(ii));
    if ~isempty(indA), 
	if ~isnan(NHcoord(indA,2:end)), %check for NaNs
        ind_NH(indA)=indA;
        ind_ratio(ii)=ii;
	end
    end
  end
end

%de-NaN the indices
ind_ratio = ind_ratio(~isnan(ind_ratio));
ind_NH = ind_NH(~isnan(ind_NH));

%prepare data sets for fit 
fit_coord = NHcoord(ind_NH,[1,5:7]);                %take protons only, for now
fit_ratio = ratio(ind_ratio,:);
%nres_ratio = length(ind_ratio);

%fitting of paramagnetic ion position

options = optimset('TolFun',1e-9,'TolX',1e-9,'MaxFunEvals',1000000,'MaxIter',100000); %options for minimization (could be different for Matlab 7!)
[position, Chi2]=fminsearch('SLfit_ss',guess,options,fit_ratio,fit_coord,factor,R2dia,Htime); %simplex minimization

disp(' ');
disp(['Chi^2 = ',num2str(Chi2)]);
disp(' ');
disp('Position of the Spin Label in the PDB coordinate frame: ');
disp([' X = ',num2str(position(1)),' A']);
disp([' Y = ',num2str(position(2)),' A']);
disp([' Z = ',num2str(position(3)),' A']);
disp(' ');

%write resulting file
if ~isempty(out_filename), 
    [s,w]=SL_add2pdb(pdb_filename,out_filename,position);
end

%back-calculate and report intensities and distances (from SL) for ALL H atoms
nres = size(NHcoord,1);
ratio_dist = NaN*ones(nres,4);
fit_ind = [];
for ii=1:nres,
    Hvect = NHcoord(ii,5:7)-position;
    dist = sqrt(Hvect*Hvect');
    R2para = factor/(dist^6);                                %evaluate Rpara
    ratio_sim = R2dia*exp(-R2para*Htime)./(R2para+R2dia);
    ratio_dist(ii,1:3) = [NHcoord(ii,1),ratio_sim,dist];
    indnn = find(fit_ratio(:,1) == ratio_dist(ii,1));        %insert PRE data (scaled)
    if ~isempty(indnn),
        ratio_dist(ii,4) = fit_ratio(indnn,2);              %output exp data that were fit
        fit_ind=[fit_ind;ii];                               %index of which are fitted data
    end
end
figure(2)
hold off
bar(ratio(:,1),ratio(:,2)); hold on
%plot(ratio_dist(:,1),ratio_dist(:,2),'ro-',ratio_dist(:,1),ratio_dist(:,4),'r*')
h=plot(ratio_dist(:,1),ratio_dist(:,2),'ro-',ratio_dist(fit_ind,1),ratio_dist(fit_ind,2),'o');
%plot(ratio_dist(:,1),ratio_dist(:,2),'ro-',ratio_dist(fit_ind,1),ratio_dist(fit_ind,2),'r*',ratio_dist(:,1),ratio_dist(:,4),'g*')
%set(h(1),'MarkerEdgeColor','r','MarkerFaceColor','none');
set(h(2),'MarkerEdgeColor','none','MarkerFaceColor','r');
xlabel('residue')
ylabel('ratio')
title('bars=experiment, o=prediction, *=actual fit')

return

%=======================================================

%Example: [position,ratio_dist,Chi2]=SLfit(ratio_sim,50e-3,5e-3,600.13,4.5,'1D3Z.pdb','test_df3.pdb',[100 100 100]);
