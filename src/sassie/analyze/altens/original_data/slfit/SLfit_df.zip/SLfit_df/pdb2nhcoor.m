function NHcoor=pdb2nhcoor(fname,reslst,model,kNaN)
%------------------------------------------------
%	df-may-03: modif df-oct-01
%	get/create NH coordinates 
%------------------------------------------------
if nargin < 4, kNaN = 1; 	end	%default: remove NaNs  %DF oct-06	
if nargin < 3, model = 1; 	end	%default: 1st structure
if nargin < 2, reslst = []; 	end	%default: all resid

[coor,atnam,at_res]=readpdb(fname,reslst,[],model); 
%--------first try the 'usual' naming convention
NHcoor=getNHcoor(coor,atnam,at_res,reslst,0);
if ~isempty(NHcoor),
   return
end
   %---------try Insight
NHcoor=getNHcoor(coor,atnam,at_res,reslst,-1);
if ~isempty(NHcoor),
   return
end
%---------build it yourself
disp('no amide Hs found in PDB, building NH vectors');
%read it again, this time all
[coor,atnam,at_res]=readpdb(fname,[],[],model); %have to read all  

iN=select_at(atnam,at_res,reslst,' N ',3,-1);
iC=select_at(atnam,at_res,reslst-1,' C ',3,-1); %modif: need preceding C!!!
iCa=select_at(atnam,at_res,reslst,' CA',3,-1);
nN=size(iN,1);
NHcoor=NaN*ones(nN,7);
NHcoor(:,1)=at_res(iN,2);
angleCaNH=121.9947;
vNHlen=1;
for ii=1:nN,
  if ~strcmp(atnam(iN(ii),11:13),'PRO'), %Non-PRO only!!!
     indC=find(at_res(iC,2)==at_res(iN(ii),2)-1);
     if ~isempty(indC),	%check if not N-term!		
         vCaN=coor(iCa(ii),:)-coor(iN(ii),:);
         vNC=coor(iN(ii),:)-coor(iC(indC),:);
         NHcoor(ii,2:4)=coor(iN(ii),:);
         NHcoor(ii,5:7)=coor(iN(ii),:)+buildH(vCaN,vNC,angleCaNH)*vNHlen;
     end
  end
end
%--- weed NaNs-----
if kNaN == 1,
  inotNaN=find(~isnan(NHcoor(:,2)));
  NHcoor=NHcoor(inotNaN,:);
end
return
%===========================================