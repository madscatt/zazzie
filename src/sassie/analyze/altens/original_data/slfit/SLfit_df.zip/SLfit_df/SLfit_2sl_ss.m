function Chi2=SLfit_2sl_ss(X,inten,at_coord,factor,R2dia,Htime,weight1);
%-----------------------------------------------------
%  df-jul-14    fit to 2 SLs
%   df-oct-09      YaR-jan-2006
%   target function for SL_fit: calculate sum or squares of residuals
%   notations and input params are similar to those in SL_fit.m 

%factor=1.23e-44*1e60; % 1/15*S(S+1)*gamma^2*g^2*beta^2 (A^6 s^-2) 

at_coord1(:,2)=at_coord(:,2)-X(1); %shift of X
at_coord1(:,3)=at_coord(:,3)-X(2); %shift of Y
at_coord1(:,4)=at_coord(:,4)-X(3); %shift of Z
at_coord2(:,2)=at_coord(:,2)-X(4); %shift of X
at_coord2(:,3)=at_coord(:,3)-X(5); %shift of Y
at_coord2(:,4)=at_coord(:,4)-X(6); %shift of Z
%weight1=X(7);

%calculate distance from SL
dist1=sqrt(at_coord1(:,2).^2+at_coord1(:,3).^2+at_coord1(:,4).^2);
dist2=sqrt(at_coord2(:,2).^2+at_coord2(:,3).^2+at_coord2(:,4).^2);

%calculate R2para
%% r(ii)=1e10*(k./Rpara(ii).*(4*tau+3*tau/(1+(omega*tau)^2))).^(1/6);

R2para1 = factor./(dist1.^6);   %calc R2para
R2para2 = factor./(dist2.^6);   %calc R2para

%calculate intensity ratio

ratio_sim=weight1*R2dia*exp(-R2para1*Htime)./(R2para1+R2dia)+...
    (1-weight1)*R2dia*exp(-R2para2*Htime)./(R2para2+R2dia);

%Calculate target function
Chi2 = sum((ratio_sim-inten(:,2)).^2);

%visualize the results
return
figure(1);   %shows agreement between experiemntal 'b' and currient curve 'r'
plot(inten(:,1),inten(:,2),'b',inten(:,1),ratio_sim,'r')
pause (0.01)

return
%=====================================================