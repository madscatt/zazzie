Matlab package SLfit

This set of programs is designed for analysis of Paramagnetic Relaxation Enhancement 
data in order to determine the location of the paramagnetic agent (Spin Label) that 
caused the PRE effect.
This package is written in Matlab and was tested using MATLAB 6.5.1 (Release 13, SP1) and Matlab 7.0.1 (Release 14, SP1).

It includes: 

(A) Programs for positioning of a Spin Label relative to a protein molecule.
The main program to call is 
SLfit.m for data analysis assuming one Spin Label 
SLfit_2sl.m for data analysis assuming two Spin Label 


(B) Program for generating synthetic PRE data, called Sim_SLdata.m

(C) A Demo program that generates synthetic data and then fits them: SLfit_demo.m 

(D) Protein coordinate file (for human ubiquitin): 1D3Z_f.pdb 
containing the first model from the original PDB entry 1D3Z


When using this package Please refer to:

Ryabov Ya., Fushman D. "Interdomain Mobility in Di-Ubiquitin Revealed by NMR", 
Proteins (2006) vol 63, pp.787-796, 2006. 
.

Modified from the original YaR version by DF, Oct 2009, then July 2014